from vllm import LLM, SamplingParams
from datasets import load_dataset
from tqdm import tqdm
import json


all_datasets = ["narrativeqa", "qasper", "multifieldqa_en", "multifieldqa_zh", "hotpotqa", "2wikimqa", "musique", \
            "dureader", "gov_report", "qmsum", "multi_news", "vcsum", "trec", "triviaqa", "samsum", "lsht", \
            "passage_count", "passage_retrieval_en", "passage_retrieval_zh", "lcc", "repobench-p"]

if __name__ == '__main__':
    # Create a sampling params object.
    # sampling_params = SamplingParams(temperature=0.8, top_p=0.95)
    sampling_params = SamplingParams(temperature=0)
    # Create an LLM.
    # meta-llama/Meta-Llama-3-8B-Instruct
    # mistralai/Mistral-7B-Instruct-v0.2
    # gradientai/Llama-3-8B-Instruct-262k
    llm = LLM(model="meta-llama/Meta-Llama-3-8B-Instruct", 
                enforce_eager=True,
                disable_sliding_window=True,
                enable_chunked_prefill=True,
                enable_sparse_kvcache=True,
                max_model_len=32000,
                max_num_seqs=64,
                token_budget=4096,
                num_repr=4,
                num_init_token=128,
                num_local_token=2048,
                enable_latency_profiling=True)
    
    dataset = "2wikimqa"
    len_limit = 32000
    data = load_dataset('THUDM/LongBench', dataset, split='test')
    dataset2prompt = json.load(open("examples/longbench2prompt.json", "r"))
    prompt_format = dataset2prompt[dataset]
    preds = []
    lens_list = []
    token_lens_list = []
    prefill_latency = []
    prefill_attn_latency = []
    decode_latency = []
    decode_attn_latency = []
    update_attn_score_prefill_latency = []
    update_attn_score_decode_latency = []
    select_block_latency = []
    select_metadata_latency = []
    cnt = 0
    for json_obj in tqdm(data):
        if cnt > 50:
            break
        cnt += 1
        if json_obj['length'] < len_limit and json_obj['language'] == "en":
            prompts = [prompt_format.format(**json_obj)]
            lens_list.append(json_obj['length'])
            outputs, latency_array = llm.generate(prompts, sampling_params)
            for output in outputs:
                num_prefill_step = len(output.prompt_token_ids) // 512
                num_decode_step = len(output.outputs[0].token_ids)
                preds.append({"pred": output.outputs[0].text, 
                            "answers": json_obj["answers"], 
                            "all_classes": json_obj["all_classes"], 
                            "length": json_obj["length"], 
                            "token_length": len(output.prompt_token_ids) + len(output.outputs[0].token_ids)})
                token_lens_list.append(len(output.prompt_token_ids) + len(output.outputs[0].token_ids))
            assert len(latency_array) == num_prefill_step + num_decode_step
            for i in range(num_prefill_step + num_decode_step):
                if i < num_prefill_step:
                    prefill_latency.append(latency_array[i][0])
                    prefill_attn_latency.append(latency_array[i][1])
                else:
                    decode_latency.append(latency_array[i][0])
                    decode_attn_latency.append(latency_array[i][1])
                if latency_array[i][2] > 0:
                    update_attn_score_prefill_latency.append(latency_array[i][2])
                if latency_array[i][3] > 0:
                    update_attn_score_decode_latency.append(latency_array[i][3])
                if latency_array[i][4] > 0:
                    select_block_latency.append(latency_array[i][4])
                if latency_array[i][5] > 0:
                    select_metadata_latency.append(latency_array[i][5])
    print("avg token len: ", sum(token_lens_list) / len(token_lens_list))
    print("max token len: ", max(token_lens_list))
    print("avg prefill latency: ", sum(prefill_latency) / len(prefill_latency))
    print("avg prefill attn latency: ", sum(prefill_attn_latency) / len(prefill_attn_latency))
    print("avg decode latency: ", sum(decode_latency) / len(decode_latency))
    print("avg decode attn latency: ", sum(decode_attn_latency) / len(decode_attn_latency))
    if len(update_attn_score_prefill_latency) > 0:
        print("avg update prefill attn score latency: ", sum(update_attn_score_prefill_latency) / len(update_attn_score_prefill_latency))
    if len(update_attn_score_decode_latency) > 0:
        print("avg update decode attn score latency: ", sum(update_attn_score_decode_latency) / len(update_attn_score_decode_latency))
    if len(select_block_latency) > 0:
        print("avg select block latency: ", sum(select_block_latency) / len(select_block_latency))
    if len(select_metadata_latency) > 0:
        print("avg select metadata latency: ", sum(select_metadata_latency) / len(select_metadata_latency))
    
    out_path = "longbench_result_{0}".format(dataset)
    with open(out_path, "w+", encoding="utf-8") as f:
        for pred in preds:
            json.dump(pred, f, ensure_ascii=False)
            f.write('\n')
    
