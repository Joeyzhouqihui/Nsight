import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Counter as CollectionsCounter
from typing import Dict, List, Optional, Protocol, Union

import numpy as np
import prometheus_client

from vllm.executor.ray_utils import ray
from vllm.logger import init_logger

class Metrics:
