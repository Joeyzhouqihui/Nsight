#pragma once

#include <torch/all.h>

// #include <faiss/gpu/utils/Select.cuh>

#include <queue>
#include <thread>
#include <unordered_map>
#include <memory>
#include "cache_lru.h"
#include "cache_io.h"
#include <numeric>

namespace vllm {

struct BlockPool {
  std::queue<int64_t> free_blocks;

  BlockPool(int64_t num_blocks) {
    for (int64_t i=0; i<num_blocks; i++) {
      free_blocks.push(i);
    }
  }

  inline int64_t num_free_blocks() {
    return free_blocks.size();
  }

  inline int64_t alloc() {
    int64_t block_id = free_blocks.front();
    free_blocks.pop();
    return block_id;
  }

  inline void free(int64_t block_id) {
    free_blocks.push(block_id);
  }

};

using MetadataBlockTable = std::unordered_map<int, std::vector<int64_t> >;
using LastBlockTable = std::unordered_map<int, std::queue<int64_t> >;
using BlockMap = std::vector<int64_t>;

struct GPUBlockCache {
  BlockPool* gpu_block_pool;
  MetadataBlockTable metadata_block_table;
  LastBlockTable last_block_table;
  BlockMap gpu_block_map, cpu_block_map;
  // cpu block id <---> gpu block id
  LRU<int64_t, int64_t> evictable_gpu_blocks;
  int64_t num_gpu_blocks, num_cpu_blocks;
  char *gpu_k_cache, *gpu_v_cache;
  char *cpu_k_cache, *cpu_v_cache;
  IOManagerPtr io_manager;
  bool is_separated_prefill_buffer;
  
  GPUBlockCache(torch::Tensor& gpu_kv_tensor, torch::Tensor& cpu_kv_tensor,
                IOManagerPtr io, bool separated_prefill_buffer) : io_manager(io) {
    gpu_k_cache = static_cast<char*>(gpu_kv_tensor[0].data_ptr());
    gpu_v_cache = static_cast<char*>(gpu_kv_tensor[1].data_ptr());
    cpu_k_cache = static_cast<char*>(cpu_kv_tensor[0].data_ptr());
    cpu_v_cache = static_cast<char*>(cpu_kv_tensor[1].data_ptr());
    num_gpu_blocks = gpu_kv_tensor.size(1);
    num_cpu_blocks = cpu_kv_tensor.size(1);
    gpu_block_pool = new BlockPool(num_gpu_blocks);
    gpu_block_map.resize(num_gpu_blocks, -1);
    cpu_block_map.resize(num_cpu_blocks, -1);
    is_separated_prefill_buffer = separated_prefill_buffer;
  }

  ~GPUBlockCache() {
    delete gpu_block_pool;
    io_manager = nullptr;
  }

  inline void evict() {
    auto ele = evictable_gpu_blocks.evict();
    int64_t cpu_block_id = ele.first;
    int64_t gpu_block_id = ele.second;
    gpu_block_map[gpu_block_id] = -1;
    cpu_block_map[cpu_block_id] = -1;
    gpu_block_pool->free(gpu_block_id);
  }

  inline int64_t allocate_gpu_block() {
    if (gpu_block_pool->num_free_blocks() == 0) {
      evict();
    }
    return gpu_block_pool->alloc();
  }

  void allocate(std::vector<int64_t> const& seq_ids,
                std::vector<int64_t> const& num_new_metadata_blocks,
                std::vector<std::vector<int64_t> > const& new_cpu_blocks) {
    int num_seqs = seq_ids.size();
    for (int i=0; i<num_seqs; i++) {
      int seq_id = seq_ids[i];
      for (int j=0; j<num_new_metadata_blocks[i]; j++) {
        metadata_block_table[seq_id].emplace_back(allocate_gpu_block());
      }
      for (auto cpu_block_id : new_cpu_blocks[i]) {
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        last_block_table[seq_id].push(gpu_block_id);
      }
    }
  }

  void get_gpu_blocks(std::vector<int64_t> const& cpu_blocks, int *gpu_blocks) {
    for (int i=0; i<cpu_blocks.size(); i++) {
      gpu_blocks[i] = cpu_block_map[cpu_blocks[i]];
    }
  }

  void get_metadata_block_table(std::vector<int64_t> const& seq_ids, std::vector<int*> &dsts) {
    for (int i=0; i<seq_ids.size(); i++) {
      int seq_id = seq_ids[i];
      int *block_table = dsts[i];
      for (int j=0; j<metadata_block_table[seq_id].size(); j++) {
        block_table[j] = metadata_block_table[seq_id][j];
      }
    }
  }

  void swap_out_kv_blocks(std::vector<int64_t> const& gpu_blocks, 
                          std::vector<int64_t> const& cpu_blocks,
                          cudaStream_t stream) {
    io_manager->swap_out(
      gpu_k_cache, cpu_k_cache,
      gpu_v_cache, cpu_v_cache,
      gpu_blocks, cpu_blocks,
      stream
    );
  }

  void swap_in_kv_blocks(std::vector<int64_t> const& cpu_blocks, 
                         std::vector<int64_t> const& gpu_blocks,
                         cudaStream_t stream) {
    io_manager->swap_in(
      cpu_k_cache, gpu_k_cache,
      cpu_v_cache, gpu_v_cache,
      cpu_blocks, gpu_blocks,
      stream
    );
  }

  void flush_kv_blocks(std::vector<int64_t> const& cpu_blocks) {
    std::vector<int64_t> gpu_blocks(cpu_blocks.size());
    for (int i=0; i<gpu_blocks.size(); i++) {
      gpu_blocks[i] = cpu_block_map[cpu_blocks[i]];
    }
    swap_out_kv_blocks(gpu_blocks, cpu_blocks, nullptr);
  }

  int load_prefill(std::vector<int64_t> const& cpu_blocks, int *gpu_blocks) {
    std::vector<int64_t> miss_cpu_blocks;
    // pin
    for (auto cpu_block_id : cpu_blocks) {
      if (cpu_block_map[cpu_block_id] < 0) {
        miss_cpu_blocks.emplace_back(cpu_block_id);
      }
      evictable_gpu_blocks.access(cpu_block_id);
    }
    // load
    if (miss_cpu_blocks.size() > 0) {
      std::vector<int64_t> miss_gpu_blocks;
      miss_gpu_blocks.reserve(miss_cpu_blocks.size());
      for (auto cpu_block_id : miss_cpu_blocks) {
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
        miss_gpu_blocks.emplace_back(gpu_block_id);
      }
      swap_in_kv_blocks(miss_cpu_blocks, miss_gpu_blocks, nullptr);
    }
    // map
    for (int i=0; i<cpu_blocks.size(); i++) {
      gpu_blocks[i] = cpu_block_map[cpu_blocks[i]];
    }
    return miss_cpu_blocks.size();
  }

  int load_batch(std::vector<int*> &cpu_blocks_batch, 
                 std::vector<int64_t> const& cpu_block_size_batch,
                 cudaStream_t stream) {
    int batch_size = cpu_blocks_batch.size();
    int total_cpu_blocks = std::accumulate(cpu_block_size_batch.begin(), cpu_block_size_batch.end(), 0);
    TORCH_CHECK(total_cpu_blocks - batch_size <= evictable_gpu_blocks.size() + gpu_block_pool->num_free_blocks());
    std::vector<int64_t> miss_cpu_blocks;
    // pin
    for (int i=0; i<batch_size; i++) {
      for (int j=0; j<cpu_block_size_batch[i]; j++) {
        int cpu_block_id = cpu_blocks_batch[i][j];
        if (cpu_block_map[cpu_block_id] < 0) {
          miss_cpu_blocks.emplace_back(cpu_block_id);
        }
        evictable_gpu_blocks.access(cpu_block_id);
      }
    }
    // load
    if (miss_cpu_blocks.size() > 0) {
      std::vector<int64_t> miss_gpu_blocks;
      miss_gpu_blocks.reserve(miss_cpu_blocks.size());
      for (auto cpu_block_id : miss_cpu_blocks) {
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
        miss_gpu_blocks.emplace_back(gpu_block_id);
      }
      swap_in_kv_blocks(miss_cpu_blocks, miss_gpu_blocks, stream);
    }
    // map
    for (int i=0; i<batch_size; i++) {
      int *cpu_blocks = cpu_blocks_batch[i];
      int cpu_block_size = cpu_block_size_batch[i];
      for (int j=0; j<cpu_block_size; j++) {
        cpu_blocks[j] = cpu_block_map[cpu_blocks[j]];
      }
    }
    return miss_cpu_blocks.size();
  }

  std::vector<int64_t> load_batch_individual(std::vector<int*> &cpu_blocks_batch, 
                                             std::vector<int64_t> const& cpu_block_size_batch,
                                             cudaStream_t stream) {
    int batch_size = cpu_blocks_batch.size();
    int total_cpu_blocks = std::accumulate(cpu_block_size_batch.begin(), cpu_block_size_batch.end(), 0);
    TORCH_CHECK(total_cpu_blocks - batch_size <= evictable_gpu_blocks.size() + gpu_block_pool->num_free_blocks());
    std::vector<int64_t> miss_cpu_blocks;
    // pin
    std::vector<int64_t> load_cnts;
    for (int i=0; i<batch_size; i++) {
      int *cpu_blocks = cpu_blocks_batch[i];
      int cpu_block_size = cpu_block_size_batch[i];
      int64_t load_cnt = 0;
      for (int j=0; j<cpu_block_size; j++) {
        int cpu_block_id = cpu_blocks[j];
        if (cpu_block_map[cpu_block_id] < 0) {
          miss_cpu_blocks.emplace_back(cpu_block_id);
          load_cnt++;
        }
        evictable_gpu_blocks.access(cpu_block_id);
      }
      load_cnts.emplace_back(load_cnt);
    }
    // load
    if (miss_cpu_blocks.size() > 0) {
      std::vector<int64_t> miss_gpu_blocks;
      miss_gpu_blocks.reserve(miss_cpu_blocks.size());
      for (auto cpu_block_id : miss_cpu_blocks) {
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
        miss_gpu_blocks.emplace_back(gpu_block_id);
      }
      swap_in_kv_blocks(miss_cpu_blocks, miss_gpu_blocks, stream);
    }
    // map
    for (int i=0; i<batch_size; i++) {
      int *cpu_blocks = cpu_blocks_batch[i];
      int cpu_block_size = cpu_block_size_batch[i];
      for (int j=0; j<cpu_block_size; j++) {
        cpu_blocks[j] = cpu_block_map[cpu_blocks[j]];
      }
    }
    return load_cnts;
  }

  void finish_flush(std::vector<int64_t> const& seq_ids) {
    for (auto seq_id : seq_ids) {
      while (last_block_table[seq_id].size() > 1) {
        int gpu_block_id = last_block_table[seq_id].front();
        last_block_table[seq_id].pop();
        int cpu_block_id = gpu_block_map[gpu_block_id];
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
      }
    }
  }

  void free_seqs(std::vector<int64_t> const& seq_ids, std::vector<std::vector<int64_t> > const& cpu_blocks) {
    int num_seqs = seq_ids.size();
    for (int i=0; i<num_seqs; i++) {
      int seq_id = seq_ids[i];
      // free metadata blocks
      for (auto gpu_block_id : metadata_block_table[seq_id]) {
        gpu_block_pool->free(gpu_block_id);
      }
      metadata_block_table.erase(seq_id);
      // free kv blocks
      for (auto cpu_block_id : cpu_blocks[i]) {
        if (cpu_block_map[cpu_block_id] >= 0) {
          int gpu_block_id = cpu_block_map[cpu_block_id];
          gpu_block_map[gpu_block_id] = -1;
          cpu_block_map[cpu_block_id] = -1;
          evictable_gpu_blocks.remove(cpu_block_id);
          gpu_block_pool->free(gpu_block_id);
        }
      }
      last_block_table.erase(seq_id);
    }
  }

};

using GPUBlockCachePtr = std::shared_ptr<GPUBlockCache>;

using PinBlockTable = std::unordered_map<int, std::vector<int64_t> >;

struct UnifiedGPUBlockCache {
  BlockPool* gpu_block_pool;
  std::vector<MetadataBlockTable> metadata_block_table;
  std::vector<LastBlockTable> last_block_table;
  BlockMap gpu_block_map, cpu_block_map;
  std::vector<int64_t> layer_cpu_block_offsets;
  // cpu block id <---> gpu block id
  LRU<int64_t, int64_t> evictable_gpu_blocks;
  int64_t num_gpu_blocks, num_cpu_blocks;
  char *gpu_k_cache, *gpu_v_cache;
  char *cpu_k_cache, *cpu_v_cache;
  IOManagerPtr io_manager;
  bool is_separated_prefill_buffer;
  PinBlockTable pin_block_table;
  int num_skip_layers;
  
  UnifiedGPUBlockCache(torch::Tensor& gpu_kv_tensor, torch::Tensor& cpu_kv_tensor,
                       IOManagerPtr io, int num_layers,
                       bool separated_prefill_buffer, int num_skips) : io_manager(io) {
    num_skip_layers = num_skips;
    metadata_block_table.resize(num_layers);
    last_block_table.resize(num_layers);
    gpu_k_cache = static_cast<char*>(gpu_kv_tensor[0].data_ptr());
    gpu_v_cache = static_cast<char*>(gpu_kv_tensor[1].data_ptr());
    cpu_k_cache = static_cast<char*>(cpu_kv_tensor[0].data_ptr());
    cpu_v_cache = static_cast<char*>(cpu_kv_tensor[1].data_ptr());
    num_gpu_blocks = gpu_kv_tensor.size(1);
    num_cpu_blocks = cpu_kv_tensor.size(1);
    gpu_block_pool = new BlockPool(num_gpu_blocks);
    gpu_block_map.resize(num_gpu_blocks, -1);
    cpu_block_map.resize(num_cpu_blocks, -1);
    int64_t num_cpu_blocks_per_layer = num_cpu_blocks / num_layers;
    layer_cpu_block_offsets.resize(num_layers);
    for (int i=0; i<num_layers; i++) {
      layer_cpu_block_offsets[i] = i * num_cpu_blocks_per_layer;
    }
    is_separated_prefill_buffer = separated_prefill_buffer;

  }

  ~UnifiedGPUBlockCache() {
    delete gpu_block_pool;
    io_manager = nullptr;
  }

  inline void evict() {
    auto ele = evictable_gpu_blocks.evict();
    int64_t cpu_block_id = ele.first;
    int64_t gpu_block_id = ele.second;
    gpu_block_map[gpu_block_id] = -1;
    cpu_block_map[cpu_block_id] = -1;
    gpu_block_pool->free(gpu_block_id);
  }

  inline int64_t allocate_gpu_block() {
    if (gpu_block_pool->num_free_blocks() == 0) {
      evict();
    }
    return gpu_block_pool->alloc();
  }

  void allocate(int layer_idx,
                std::vector<int64_t> const& seq_ids,
                std::vector<int64_t> const& num_new_metadata_blocks,
                std::vector<std::vector<int64_t> > const& new_cpu_blocks) {
    int64_t cpu_block_offset = layer_cpu_block_offsets[layer_idx];
    for (int i=0; i<seq_ids.size(); i++) {
      int seq_id = seq_ids[i];
      for (int j=0; j<num_new_metadata_blocks[i]; j++) {
        metadata_block_table[layer_idx][seq_id].emplace_back(allocate_gpu_block());
      }
      for (int j=0; j<new_cpu_blocks[i].size(); j++) {
        int64_t cpu_block_id = new_cpu_blocks[i][j] + cpu_block_offset;
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        last_block_table[layer_idx][seq_id].push(gpu_block_id);
      }
    }
  }

  void get_gpu_blocks(int layer_idx, std::vector<int64_t> const& cpu_blocks, int *gpu_blocks) {
    int64_t cpu_block_offset = layer_cpu_block_offsets[layer_idx];
    for (int i=0; i<cpu_blocks.size(); i++) {
      int64_t cpu_block_id = cpu_blocks[i] + cpu_block_offset;
      gpu_blocks[i] = cpu_block_map[cpu_block_id];
    }
  }

  void get_metadata_block_table(int layer_idx,
                                std::vector<int64_t> const& seq_ids,
                                std::vector<int*> &dsts) {
    for (int i=0; i<seq_ids.size(); i++) {
      int seq_id = seq_ids[i];
      int *block_table = dsts[i];
      for (int j=0; j<metadata_block_table[layer_idx][seq_id].size(); j++) {
        block_table[j] = metadata_block_table[layer_idx][seq_id][j];
      }
    }
  }

  void swap_out_kv_blocks(std::vector<int64_t> const& gpu_blocks, 
                          std::vector<int64_t> const& cpu_blocks,
                          cudaStream_t stream) {
    io_manager->swap_out(
      gpu_k_cache, cpu_k_cache,
      gpu_v_cache, cpu_v_cache,
      gpu_blocks, cpu_blocks,
      stream
    );
  }

  void swap_in_kv_blocks(std::vector<int64_t> const& cpu_blocks, 
                         std::vector<int64_t> const& gpu_blocks,
                         cudaStream_t stream) {
    io_manager->swap_in(
      cpu_k_cache, gpu_k_cache,
      cpu_v_cache, gpu_v_cache,
      cpu_blocks, gpu_blocks,
      stream
    );
  }

  void flush_kv_blocks(int layer_idx, std::vector<int64_t> const& cpu_blocks) {
    int64_t cpu_block_offset = layer_cpu_block_offsets[layer_idx];
    std::vector<int64_t> real_cpu_blocks(cpu_blocks.size());
    std::vector<int64_t> gpu_blocks(cpu_blocks.size());
    for (int i=0; i<cpu_blocks.size(); i++) {
      real_cpu_blocks[i] = cpu_blocks[i] + cpu_block_offset;
      gpu_blocks[i] = cpu_block_map[real_cpu_blocks[i]];
    }
    swap_out_kv_blocks(gpu_blocks, real_cpu_blocks, nullptr);
  }

  int load_prefill(int layer_idx, std::vector<int64_t> const& cpu_blocks, int *gpu_blocks) {
    int64_t cpu_block_offset = layer_cpu_block_offsets[layer_idx];
    std::vector<int64_t> miss_cpu_blocks;
    // pin
    for (int i=0; i<cpu_blocks.size(); i++) {
      int64_t cpu_block_id = cpu_blocks[i] + cpu_block_offset;
      if (cpu_block_map[cpu_block_id] < 0) {
        miss_cpu_blocks.emplace_back(cpu_block_id);
      }
      evictable_gpu_blocks.access(cpu_block_id);
    }
    // load
    if (miss_cpu_blocks.size() > 0) {
      std::vector<int64_t> miss_gpu_blocks;
      miss_gpu_blocks.reserve(miss_cpu_blocks.size());
      for (int64_t cpu_block_id : miss_cpu_blocks) {
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
        miss_gpu_blocks.emplace_back(gpu_block_id);
      }
      swap_in_kv_blocks(miss_cpu_blocks, miss_gpu_blocks, nullptr);
    }
    // map
    for (int i=0; i<cpu_blocks.size(); i++) {
      int cpu_block_id = cpu_blocks[i] + cpu_block_offset;
      gpu_blocks[i] = cpu_block_map[cpu_block_id];
    }
    return miss_cpu_blocks.size();
  }

  int load_batch(int layer_idx, 
                 std::vector<int*> &cpu_blocks_batch, 
                 std::vector<int64_t> const& cpu_block_size_batch,
                 cudaStream_t stream) {
    int batch_size = cpu_blocks_batch.size();
    int64_t cpu_block_offset = layer_cpu_block_offsets[layer_idx];
    int total_cpu_blocks = std::accumulate(cpu_block_size_batch.begin(), cpu_block_size_batch.end(), 0);
    if (layer_idx >= num_skip_layers) {
      TORCH_CHECK(total_cpu_blocks - batch_size <= evictable_gpu_blocks.size() + gpu_block_pool->num_free_blocks());
    }
    std::vector<int64_t> miss_cpu_blocks;
    // pin
    for (int i=0; i<cpu_blocks_batch.size(); i++) {
      int *cpu_blocks = cpu_blocks_batch[i];
      int cpu_block_size = cpu_block_size_batch[i];
      for (int j=0; j<cpu_block_size; j++) {
        int64_t cpu_block_id = cpu_blocks[j] + cpu_block_offset;
        if (cpu_block_map[cpu_block_id] < 0) {
          miss_cpu_blocks.emplace_back(cpu_block_id);
        }
        evictable_gpu_blocks.access(cpu_block_id);
      }
    }
    // load
    if (miss_cpu_blocks.size() > 0) {
      std::vector<int64_t> miss_gpu_blocks;
      miss_gpu_blocks.reserve(miss_cpu_blocks.size());
      for (auto cpu_block_id : miss_cpu_blocks) {
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
        miss_gpu_blocks.emplace_back(gpu_block_id);
      }
      swap_in_kv_blocks(miss_cpu_blocks, miss_gpu_blocks, stream);
    }
    // map
    for (int i=0; i<cpu_blocks_batch.size(); i++) {
      int *cpu_blocks = cpu_blocks_batch[i];
      int cpu_block_size = cpu_block_size_batch[i];
      for (int j=0; j<cpu_block_size; j++) {
        int64_t cpu_block_id = cpu_blocks[j] + cpu_block_offset;
        cpu_blocks[j] = cpu_block_map[cpu_block_id];
      }
    }
    return miss_cpu_blocks.size();
  }

  std::vector<int64_t> load_batch_individual(int layer_idx, 
                                             std::vector<int*> &cpu_blocks_batch, 
                                             std::vector<int64_t> const& cpu_block_size_batch,
                                             cudaStream_t stream) {
    int batch_size = cpu_blocks_batch.size();
    int64_t cpu_block_offset = layer_cpu_block_offsets[layer_idx];
    int total_cpu_blocks = std::accumulate(cpu_block_size_batch.begin(), cpu_block_size_batch.end(), 0);
    if (layer_idx >= num_skip_layers) {
      TORCH_CHECK(total_cpu_blocks - batch_size <= evictable_gpu_blocks.size() + gpu_block_pool->num_free_blocks());
    }
    std::vector<int64_t> miss_cpu_blocks;
    // pin
    std::vector<int64_t> load_cnts;
    for (int i=0; i<cpu_blocks_batch.size(); i++) {
      int *cpu_blocks = cpu_blocks_batch[i];
      int cpu_block_size = cpu_block_size_batch[i];
      int64_t load_cnt = 0;
      for (int j=0; j<cpu_block_size; j++) {
        int64_t cpu_block_id = cpu_blocks[j] + cpu_block_offset;
        if (cpu_block_map[cpu_block_id] < 0) {
          miss_cpu_blocks.emplace_back(cpu_block_id);
          load_cnt++;
        }
        evictable_gpu_blocks.access(cpu_block_id);
      }
      load_cnts.emplace_back(load_cnt);
    }
    // load
    if (miss_cpu_blocks.size() > 0) {
      std::vector<int64_t> miss_gpu_blocks;
      miss_gpu_blocks.reserve(miss_cpu_blocks.size());
      for (auto cpu_block_id : miss_cpu_blocks) {
        int64_t gpu_block_id = allocate_gpu_block();
        gpu_block_map[gpu_block_id] = cpu_block_id;
        cpu_block_map[cpu_block_id] = gpu_block_id;
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
        miss_gpu_blocks.emplace_back(gpu_block_id);
      }
      swap_in_kv_blocks(miss_cpu_blocks, miss_gpu_blocks, stream);
    }
    // map
    for (int i=0; i<cpu_blocks_batch.size(); i++) {
      int *cpu_blocks = cpu_blocks_batch[i];
      int cpu_block_size = cpu_block_size_batch[i];
      for (int j=0; j<cpu_block_size; j++) {
        int64_t cpu_block_id = cpu_blocks[j] + cpu_block_offset;
        cpu_blocks[j] = cpu_block_map[cpu_block_id];
      }
    }
    return load_cnts;
  }

  inline void finish_flush_decode(int layer_idx, int seq_id) {
    while (last_block_table[layer_idx][seq_id].size() > 1) {
      int gpu_block_id = last_block_table[layer_idx][seq_id].front();
      last_block_table[layer_idx][seq_id].pop();
      int cpu_block_id = gpu_block_map[gpu_block_id];
      if (layer_idx < num_skip_layers) {
        pin_block_table[seq_id].emplace_back(cpu_block_id);
      } else {
        evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
      }
    }
  }

  inline void finish_flush_prefill(int layer_idx, int seq_id) {
    if (is_separated_prefill_buffer) {
      while (last_block_table[layer_idx][seq_id].size() > 1) {
        int gpu_block_id = last_block_table[layer_idx][seq_id].front();
        last_block_table[layer_idx][seq_id].pop();
        int cpu_block_id = gpu_block_map[gpu_block_id];
        if (layer_idx < num_skip_layers) {
          pin_block_table[seq_id].emplace_back(cpu_block_id);
        } else {
          evictable_gpu_blocks.add_back(cpu_block_id, gpu_block_id);
        }
      }
    } else {
      while (last_block_table[layer_idx][seq_id].size() > 1) {
        int gpu_block_id = last_block_table[layer_idx][seq_id].front();
        last_block_table[layer_idx][seq_id].pop();
        int cpu_block_id = gpu_block_map[gpu_block_id];
        if (layer_idx < num_skip_layers) {
          pin_block_table[seq_id].emplace_back(cpu_block_id);
        } else {
          evictable_gpu_blocks.add(cpu_block_id, gpu_block_id);
        }
      }
    }
  }
  
  void finish_flush(int layer_idx, std::vector<int64_t> const& seq_ids) {
    for (auto seq_id : seq_ids) {
      if (last_block_table[layer_idx][seq_id].size() > 2) {
        finish_flush_prefill(layer_idx, seq_id);
      } else {
        finish_flush_decode(layer_idx, seq_id);
      }
    }
  }

  void free_seqs(std::vector<int64_t> const& seq_ids, std::vector<std::vector<int64_t> > const& cpu_blocks) {
    int num_layers = metadata_block_table.size();
    for (int i=0; i<seq_ids.size(); i++) {
      int seq_id = seq_ids[i];
      pin_block_table.erase(seq_id);
      for (int layer_id = 0; layer_id < num_layers; layer_id++) {
        // free metadata blocks
        for (auto gpu_block_id : metadata_block_table[layer_id][seq_id]) {
          gpu_block_pool->free(gpu_block_id);
        }
        metadata_block_table[layer_id].erase(seq_id);
        last_block_table[layer_id].erase(seq_id);
        // free kv blocks
        int64_t cpu_block_offset = layer_cpu_block_offsets[layer_id];
        for (int j=0; j<cpu_blocks[i].size(); j++) {
          int64_t cpu_block_id = cpu_blocks[i][j] + cpu_block_offset;
          int64_t gpu_block_id = cpu_block_map[cpu_block_id];
          if (gpu_block_id >= 0) {
            gpu_block_map[gpu_block_id] = -1;
            cpu_block_map[cpu_block_id] = -1;
            evictable_gpu_blocks.remove(cpu_block_id);
            gpu_block_pool->free(gpu_block_id);
          }
        }
      }
    }
  }

};

using UnifiedGPUBlockCachePtr = std::shared_ptr<UnifiedGPUBlockCache>;

}
