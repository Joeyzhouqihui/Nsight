#pragma once

#include <torch/all.h>

// #include <faiss/gpu/utils/Select.cuh>

#include <map>
#include <vector>
#include <thread>

void init_cache(std::vector<torch::Tensor> const& gpu_kv_cache,
                std::vector<torch::Tensor> const& cpu_kv_cache,
                int64_t num_layers, int64_t num_heads,
                bool separated_prefill_buffer,
                bool enable_parallel_attn,
                int64_t num_skip_layers);

void sync_flush(int64_t layer_idx);

void allocate(int64_t layer_idx,
              std::vector<int64_t> const& seq_ids,
              std::vector<int64_t> const& num_new_metadata_blocks,
              std::vector<std::vector<int64_t> > const& new_kv_block_table);

void map_kv_blocks(int64_t layer_idx, 
                   std::vector<int64_t> const& cpu_blocks,
                   torch::Tensor& gpu_blocks);

void get_metadata_block_table(int64_t layer_idx, 
                              std::vector<int64_t> const& seq_ids,
                              torch::Tensor& metadata_block_tables);

void flush_kv_blocks(int64_t layer_idx, std::vector<int64_t> const& cpu_blocks);

int64_t load_prefill(int64_t layer_idx,
                     std::vector<std::vector<int64_t> > const& cpu_block_tables,
                     torch::Tensor& prefill_block_tables_tensor);

int64_t load_decode_full(int64_t layer_idx,
                         std::vector<std::vector<int64_t> > const& cpu_block_tables,
                         torch::Tensor& decode_block_tables_tensor);

int64_t load_decode(int64_t layer_idx,
                    std::vector<int64_t> const& select_num_cpu_blocks,
                    torch::Tensor& decode_block_tables_tensor);

std::vector<int64_t> load_decode_individual(int64_t layer_idx,
                                            std::vector<int64_t> const& select_num_cpu_blocks,
                                            torch::Tensor& decode_block_tables_tensor);

void finish_flush(int64_t layer_idx, std::vector<int64_t> const& seq_ids);

void free_seqs(std::vector<int64_t> const& seq_ids, std::vector<std::vector<int64_t> > const& cpu_block_tables);

std::vector<int64_t> progressive_attn(int64_t layer_idx,
                                      torch::Tensor& query_tensor,
                                      torch::Tensor& kcache_tensor,
                                      torch::Tensor& vcache_tensor,
                                      torch::Tensor& out_tensor,
                                      double softmax_scale,
                                        std::vector<int64_t> const& seq_lens,
                                        torch::Tensor& seq_lens_tensor,
                                        torch::Tensor& rank_block_tables_tensor,
                                        torch::Tensor& micro_seq_lens_tensor_list,
                                        torch::Tensor& micro_block_tables_tensor_list,
                                        torch::Tensor& micro_es_sum_tensor_list,
                                        torch::Tensor& micro_es_min_tensor_list,
                                        torch::Tensor& micro_es_buffer_tensor,
                                        torch::Tensor& micro_output_tensor_list,
                                        int64_t micro_chunk_size, 
                                        double threshold);

void swap_blocks(torch::Tensor& src, torch::Tensor& dst,
                 const torch::Tensor& block_mapping);

// Note: the key_caches and value_caches vectors are constant but
// not the Tensors they contain. The vectors need to be const refs
// in order to satisfy pytorch's C++ operator registration code.
void copy_blocks(std::vector<torch::Tensor> const& key_caches,
                 std::vector<torch::Tensor> const& value_caches,
                 const torch::Tensor& block_mapping);

void reshape_and_cache(torch::Tensor& key, torch::Tensor& value,
                       torch::Tensor& key_cache, torch::Tensor& value_cache,
                       torch::Tensor& slot_mapping,
                       const std::string& kv_cache_dtype, const double k_scale,
                       const double v_scale);

void reshape_and_cache_flash(torch::Tensor& key, torch::Tensor& value,
                             torch::Tensor& key_cache,
                             torch::Tensor& value_cache,
                             torch::Tensor& slot_mapping,
                             const std::string& kv_cache_dtype,
                             const double k_scale, const double v_scale);

void reshape_and_cache_flash2(int64_t layer_idx,
                              torch::Tensor& key, 
                              torch::Tensor& value,
                              torch::Tensor& key_cache,
                              torch::Tensor& value_cache,
                              torch::Tensor& slot_block_mapping,
                              torch::Tensor& slot_offset_mapping,
                              std::vector<int64_t> const& slot_cpu_blocks,
                              torch::Tensor& slot_gpu_blocks_tensor,
                              const std::string& kv_cache_dtype,
                              const double k_scale, const double v_scale);

void compute_and_cache_metadata_flash(torch::Tensor& new_kv_blocks,
                                      torch::Tensor& key_cache,
                                      torch::Tensor& value_cache,
                                      torch::Tensor& slot_mapping);

void compute_and_cache_metadata_flash2(int64_t layer_idx,
                                       torch::Tensor& new_full_cpu_blocks_offsets_tensor,
                                       std::vector<int64_t> const& new_full_cpu_blocks,
                                       torch::Tensor& new_full_cpu_blocks_tensor,
                                       int64_t max_num_new_kv_blocks,
                                       std::vector<int64_t> const& seq_ids,
                                       torch::Tensor& context_lens,
                                       torch::Tensor& seq_lens,
                                       torch::Tensor& metadata_block_tables_tensor,
                                       torch::Tensor& key_cache,
                                       torch::Tensor& value_cache);

void estimate_scores_flash(int64_t layer_idx,
                           torch::Tensor& decode_query,
                           std::vector<int64_t> const& seq_ids,
                           torch::Tensor& seq_lens_tensor,
                           torch::Tensor& metadata_block_tables,
                           torch::Tensor& key_cache,
                           torch::Tensor& value_cache,
                           torch::Tensor& block_scores);

void select_topk_decode_blocks_flash(torch::Tensor& block_tables,
                                     torch::Tensor& seq_lens_tensor,
                                     torch::Tensor& block_scores_tensor,
                                     int64_t num_select,
                                     torch::Tensor& select_block_tables);

void rank_decode_blocks_flash(torch::Tensor& block_tables,
                              torch::Tensor& seq_lens_tensor,
                              torch::Tensor& block_scores_tensor,
                              torch::Tensor& rank_block_tables,
                              int64_t num_init,
                              int64_t num_local);

void process_es(torch::Tensor& softmax_lse,
                torch::Tensor& es,
                torch::Tensor& seq_lens,
                torch::Tensor& es_sum,
                torch::Tensor& es_min);

void select_and_cache_metadata_flash(torch::Tensor& block_tables, 
                                     torch::Tensor& metadata_context_lens_tensor,
                                     torch::Tensor& metadata_lens_tensor, 
                                     torch::Tensor& metadata_start_loc,
                                     torch::Tensor& metadata_slot_mapping,
                                     torch::Tensor& attn_score_block_tensor,
                                     torch::Tensor& repr_token_indices,
                                     torch::Tensor& key_cache,
                                     torch::Tensor& metadata_cache,
                                     torch::Tensor& attention_scores);                                 


void update_attn_scores_prefill_flash(torch::Tensor& new_attn_scores,
                                      torch::Tensor& context_lens_tensor,
                                      torch::Tensor& seq_lens_tensor,
                                      torch::Tensor& attn_score_block_tensor,
                                      torch::Tensor& attention_scores,
                                      int64_t num_local_tokens);


void update_attn_scores_decode_flash(torch::Tensor& new_attn_scores,
                                     torch::Tensor& context_lens_tensor,
                                     torch::Tensor& seq_lens_tensor,
                                     torch::Tensor& attn_score_block_tensor,
                                     torch::Tensor& attention_scores,
                                     int64_t num_local_tokens);


void select_decode_blocks_flash(torch::Tensor& decode_query, 
                                torch::Tensor& block_tables,
                                torch::Tensor& seq_lens_tensor, 
                                torch::Tensor& metadata_block_tables,
                                torch::Tensor& metadata_context_lens_tensor,
                                int64_t block_budget, 
                                int64_t num_init_block, 
                                int64_t num_retrieval_block, 
                                int64_t num_local_block,
                                torch::Tensor& approx_attn_scores,
                                torch::Tensor& select_block_tables,
                                torch::Tensor& select_seq_lens_tensor, 
                                torch::Tensor& metadata_cache);

// Just for unittest
void convert_fp8(torch::Tensor& dst_cache, torch::Tensor& src_cache,
                 const double scale, const std::string& kv_cache_dtype);
