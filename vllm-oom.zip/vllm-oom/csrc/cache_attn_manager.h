#pragma once

#include <torch/all.h>

// #include <faiss/gpu/utils/Select.cuh>

#include "concurrentqueue.h"
#include <atomic>
#include <vector>
#include <thread>
#include <memory>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include "cache_utils.h"
#include "cache_flash_api.h"
#include <semaphore.h>
#include <torch/script.h>

namespace vllm {

struct AttnState {
    int layer_idx;
    torch::Tensor query_tensor;
    torch::Tensor kcache_tensor;
    torch::Tensor vcache_tensor;
    torch::Tensor out_tensor;
    float softmax_scale;
    std::vector<int64_t> seq_lens;
    torch::Tensor seq_lens_tensor;
    torch::Tensor rank_block_tables_tensor;
    torch::Tensor micro_seq_lens_tensor_list;
    torch::Tensor micro_block_tables_tensor_list;
    torch::Tensor micro_es_sum_tensor_list;
    torch::Tensor micro_es_min_tensor_list;
    torch::Tensor micro_es_buffer_tensor;
    torch::Tensor micro_output_tensor_list;
    int micro_chunk_size;
    float threshold;
    int max_num_chunks;
};

using AttnStatePtr = std::shared_ptr<AttnState>;

struct AttnManager {
    bool is_unified_gpu_cache;
    std::vector<GPUBlockCachePtr> gpu_block_caches;
    UnifiedGPUBlockCachePtr unified_gpu_block_cache;
    int block_size, num_heads;
    torch::Tensor rank_block_tables_tensor_cpu;
    torch::Tensor micro_seq_lens_tensor_cpu, micro_block_tables_tensor_cpu;
    moodycamel::ConcurrentQueue<AttnStatePtr> load_task_que;
    std::atomic<int> load_budget, compute_budget;
    // for gpu side verify
    torch::Tensor es_acc, es_min;
    volatile int *seq_states;
    volatile int *compute_barrier;
    volatile int *buffer_states;
    std::atomic<bool> is_finish;
    cudaStream_t load_stream;
    std::thread *load_thread;
    std::atomic<int> load_version, compute_version;
    std::atomic<int> load_cnt_total;
    std::atomic<bool> is_stop;
    bool parallel_attn;
    int num_skip_layers;

    AttnManager(bool is_unified,
                std::vector<GPUBlockCachePtr> &gpu_caches, 
                UnifiedGPUBlockCachePtr unified_cache,
                int block_sz, int n_heads,
                bool enable_parallel_attn,
                int num_skip) : is_unified_gpu_cache(is_unified), block_size(block_sz), num_heads(n_heads), is_stop(false) {
        num_skip_layers = num_skip;
        for (int i=0; i<gpu_caches.size(); i++) {
          gpu_block_caches.push_back(gpu_caches[i]);
        }
        unified_gpu_block_cache = unified_cache;
        es_acc = torch::empty({64, 256}, torch::dtype(torch::kFloat).device(torch::kCUDA));
        es_min = torch::empty({64, 256}, torch::dtype(torch::kFloat).device(torch::kCUDA));
        cudaHostAlloc((void **)&seq_states, sizeof(int) * 256, cudaHostAllocMapped);
        cudaHostAlloc((void **)&compute_barrier, sizeof(int), cudaHostAllocMapped);
        cudaHostAlloc((void **)&buffer_states, sizeof(int) * 256, cudaHostAllocMapped);
        rank_block_tables_tensor_cpu = torch::empty({64, 4096}, torch::dtype(torch::kInt32)).pin_memory();
        micro_seq_lens_tensor_cpu = torch::empty({64}, torch::dtype(torch::kInt32)).pin_memory();
        micro_block_tables_tensor_cpu = torch::empty({64, 4096}, torch::dtype(torch::kInt32)).pin_memory();
        reset_state(nullptr);
        cudaStreamCreateWithFlags(&load_stream, cudaStreamNonBlocking);
        load_budget = 0;
        compute_budget = 0;
        load_version = 0;
        compute_version = 0;
        is_finish = false;
        parallel_attn = enable_parallel_attn;
        if (parallel_attn) {
          load_thread = new std::thread(&AttnManager::load_work, this);
        } else {
          load_thread = nullptr;
        }
    }

    ~AttnManager() {
        is_stop = true;
        if (load_thread != nullptr) {
          load_thread->join();
          delete load_thread;
        }
    }

    inline void reset_state(AttnStatePtr attn_state) {
      for (int i=0; i<256; i++) {
        *(seq_states + i) = 1;
      }
      *compute_barrier = 0;
    }

    inline bool is_all_finish(AttnStatePtr attn_state) {
      if (is_finish) {
        return true;
      }
      int batch_size = attn_state->seq_lens.size();
      for (int i=0; i<batch_size; i++) {
        if (*(seq_states + i) > 0) {
          return false;
        }
      }
      is_finish = true;
      return true;
    }

    inline int load_chunk_block_table(AttnStatePtr attn_state, int iteration) {
      int layer_idx = attn_state->layer_idx;
      std::vector<int64_t> &seq_lens = attn_state->seq_lens;
      int *rank_block_tables_cpu_ptr = reinterpret_cast<int*>(rank_block_tables_tensor_cpu.data_ptr());
      int *micro_seq_lens_gpu_ptr = reinterpret_cast<int*>(attn_state->micro_seq_lens_tensor_list.data_ptr()) + iteration * attn_state->micro_seq_lens_tensor_list.stride(0);
      int *micro_seq_lens_cpu_ptr = reinterpret_cast<int*>(micro_seq_lens_tensor_cpu.data_ptr());
      int *micro_block_tables_gpu_ptr = reinterpret_cast<int*>(attn_state->micro_block_tables_tensor_list.data_ptr()) + iteration * attn_state->micro_block_tables_tensor_list.stride(0);
      int *micro_block_tables_cpu_ptr = reinterpret_cast<int*>(micro_block_tables_tensor_cpu.data_ptr());
      int micro_chunk_size = attn_state->micro_chunk_size;
      int block_table_stride = attn_state->rank_block_tables_tensor.stride(0);
      int micro_block_tables_stride = attn_state->micro_block_tables_tensor_list.stride(1);
      std::vector<int*> cpu_blocks_batch;
      std::vector<int64_t> select_num_cpu_blocks;
      for (int i=0; i<seq_lens.size(); i++) {
        micro_seq_lens_cpu_ptr[i] = 0;
        if (*(seq_states + i) != 0) {
          int num_blocks = (seq_lens[i] + block_size - 1) / block_size;
          int num_blocks_left = num_blocks - iteration * micro_chunk_size;
          if (num_blocks_left <= 0) {
            continue;
          }
          int num_select = (num_blocks_left < micro_chunk_size ? num_blocks_left : micro_chunk_size);
          int *block_table = rank_block_tables_cpu_ptr + i * block_table_stride;
          int *micro_block_table = micro_block_tables_cpu_ptr + i * micro_block_tables_stride;
          if (iteration == 0) {
            int last_block_size = seq_lens[i] - (num_blocks - 1) * block_size;
            micro_seq_lens_cpu_ptr[i] = (num_select - 1) * block_size + last_block_size;
            micro_block_table[num_select - 1] = block_table[num_blocks - 1];
            for (int j=0; j<num_select-1; j++) {
              micro_block_table[j] = block_table[j];
            }
          } else {
            micro_seq_lens_cpu_ptr[i] = num_select * block_size;
            int init_offset = micro_chunk_size * iteration - 1;
            for (int j=0; j<num_select; j++) {
              micro_block_table[j] = block_table[init_offset + j];
            }
          }
          cpu_blocks_batch.emplace_back(micro_block_table);
          select_num_cpu_blocks.emplace_back(num_select);
        }
      }
      int total_load_cnt = -1;
      if (cpu_blocks_batch.size() > 0) {
        if (is_unified_gpu_cache) {
          total_load_cnt = unified_gpu_block_cache->load_batch(layer_idx, cpu_blocks_batch, select_num_cpu_blocks, load_stream);
        } else {
          total_load_cnt = gpu_block_caches[layer_idx]->load_batch(cpu_blocks_batch, select_num_cpu_blocks, load_stream);
        }
        int micro_seq_lens_in_bytes = attn_state->micro_seq_lens_tensor_list.element_size() * attn_state->micro_seq_lens_tensor_list.stride(0);
        int micro_block_tables_in_bytes = attn_state->micro_block_tables_tensor_list.element_size() * attn_state->micro_block_tables_tensor_list.stride(0);
        cudaMemcpyAsync(
          micro_seq_lens_gpu_ptr,
          micro_seq_lens_cpu_ptr,
          micro_seq_lens_in_bytes, 
          cudaMemcpyHostToDevice,
          load_stream
        );
        cudaMemcpyAsync(
          micro_block_tables_gpu_ptr,
          micro_block_tables_cpu_ptr,
          micro_block_tables_in_bytes,
          cudaMemcpyHostToDevice,
          load_stream
        );
        cudaStreamSynchronize(load_stream);
      }
      return total_load_cnt;
    }

    void load_work() {
      while (!is_stop) {
          AttnStatePtr attn_state = nullptr;
          if (load_task_que.try_dequeue(attn_state)) {
              int max_iteration = attn_state->max_num_chunks;
              int load_iteration = 0;
              while (!is_all_finish(attn_state)) {
                if (load_budget > 0) {
                  load_budget--;
                  if (load_iteration >= max_iteration) {
                    break;
                  }
                  int load_cnt = load_chunk_block_table(attn_state, load_iteration);
                  if (load_cnt < 0) {
                    break;
                  }
                  load_cnt_total += load_cnt;
                  load_iteration++;
                  compute_budget++;
                }
              }
              load_version++;
          }
      }
    }

    inline void progessive_attn_fwd(AttnStatePtr attn_state) {
      flash_attn_fwd(
        attn_state->query_tensor,
        attn_state->kcache_tensor,
        attn_state->vcache_tensor,
        attn_state->micro_block_tables_tensor_list,
        attn_state->micro_seq_lens_tensor_list,
        attn_state->micro_output_tensor_list,
        attn_state->micro_es_sum_tensor_list,
        attn_state->micro_es_min_tensor_list,
        attn_state->micro_es_buffer_tensor,
        attn_state->softmax_scale,
        reinterpret_cast<float*>(es_acc.data_ptr()),
        reinterpret_cast<float*>(es_min.data_ptr()),
        reinterpret_cast<int*>(attn_state->seq_lens_tensor.data_ptr()),
        attn_state->micro_chunk_size,
        attn_state->threshold,
        load_budget,
        compute_budget,
        seq_states,
        compute_barrier
      );
    }

    inline void merge_attn_fwd(AttnStatePtr attn_state, int iteration) {
      merge_attn_flash(
        attn_state->micro_output_tensor_list,
        attn_state->micro_es_sum_tensor_list,
        attn_state->micro_seq_lens_tensor_list,
        attn_state->out_tensor,
        iteration
      );
    }

    inline int plain_attn_fwd(AttnStatePtr attn_state) {
      const cudaStream_t stream = at::cuda::getCurrentCUDAStream();
      int layer_idx = attn_state->layer_idx;
      std::vector<int64_t>& seq_lens = attn_state->seq_lens;
      int block_table_stride = attn_state->rank_block_tables_tensor.stride(0);
      std::vector<int*> cpu_blocks_batch;
      std::vector<int64_t> select_num_cpu_blocks;
      int *rank_block_tables_cpu_ptr = reinterpret_cast<int*>(rank_block_tables_tensor_cpu.data_ptr());
      for (int i=0; i<seq_lens.size(); i++) {
        int num_blocks = (seq_lens[i] + block_size - 1) / block_size;
        int *block_table = rank_block_tables_cpu_ptr + i * block_table_stride;
        cpu_blocks_batch.emplace_back(block_table);
        select_num_cpu_blocks.emplace_back(num_blocks);
      }
      int total_load_cnt;
      if (is_unified_gpu_cache) {
        total_load_cnt = unified_gpu_block_cache->load_batch(layer_idx, cpu_blocks_batch, select_num_cpu_blocks, stream);
      } else {
        total_load_cnt = gpu_block_caches[layer_idx]->load_batch(cpu_blocks_batch, select_num_cpu_blocks, stream);
      }
      int block_tables_in_bytes = attn_state->rank_block_tables_tensor.element_size() * attn_state->rank_block_tables_tensor.numel();
      cudaMemcpyAsync(
        attn_state->rank_block_tables_tensor.data_ptr(),
        rank_block_tables_cpu_ptr,
        block_tables_in_bytes,
        cudaMemcpyHostToDevice,
        stream
      );
      torch::Tensor block_table_ = attn_state->rank_block_tables_tensor;
      torch::Tensor seqlens_k_ = attn_state->seq_lens_tensor;
      torch::Tensor out_ = attn_state->out_tensor;
      flash_attn_fwd_plain(
        attn_state->query_tensor,
        attn_state->kcache_tensor,
        attn_state->vcache_tensor,
        block_table_,
        seqlens_k_,
        out_,
        attn_state->softmax_scale
      );
      // cudaStreamSynchronize(stream);
      return total_load_cnt;
    }

    inline void plain_attn_fwd_chunk(AttnStatePtr attn_state, int iteration) {
      torch::Tensor block_table_ = attn_state->micro_block_tables_tensor_list[iteration];
      torch::Tensor seqlens_k_ = attn_state->micro_seq_lens_tensor_list[iteration];
      torch::Tensor out_ = attn_state->micro_output_tensor_list[iteration];
      torch::Tensor out_es_sum_ = attn_state->micro_es_sum_tensor_list[iteration];
      flash_attn_fwd_plain_chunk(
        attn_state->query_tensor,
        attn_state->kcache_tensor,
        attn_state->vcache_tensor,
        block_table_,
        seqlens_k_,
        out_,
        out_es_sum_,
        attn_state->softmax_scale
      );
    }

    inline void sync_load() {
      while (load_version < compute_version);
    }

    std::vector<int64_t> progressive_attn_sequential(int layer_idx,
                                          torch::Tensor& query_tensor,
                                          torch::Tensor& kcache_tensor,
                                          torch::Tensor& vcache_tensor,
                                          torch::Tensor& out_tensor,
                                          float softmax_scale,
                                          std::vector<int64_t> const& seq_lens,
                                          torch::Tensor& seq_lens_tensor,
                                          torch::Tensor& rank_block_tables_tensor,
                                          torch::Tensor& micro_seq_lens_tensor_list,
                                          torch::Tensor& micro_block_tables_tensor_list,
                                          torch::Tensor& micro_es_sum_tensor_list,
                                          torch::Tensor& micro_es_min_tensor_list,
                                          torch::Tensor& micro_es_buffer_tensor,
                                          torch::Tensor& micro_output_tensor_list,
                                          int micro_chunk_size,
                                          float threshold) {
      const cudaStream_t stream = at::cuda::getCurrentCUDAStream();
      int table_size_in_bytes = rank_block_tables_tensor.element_size() * rank_block_tables_tensor.numel();
      cudaMemcpyAsync(
        reinterpret_cast<int*>(rank_block_tables_tensor_cpu.data_ptr()),
        rank_block_tables_tensor.data_ptr(), 
        table_size_in_bytes, 
        cudaMemcpyDeviceToHost,
        stream
      );          
      AttnStatePtr attn_state = std::make_shared<AttnState>();
      attn_state->layer_idx = layer_idx;
      attn_state->query_tensor = query_tensor;
      attn_state->kcache_tensor = kcache_tensor;
      attn_state->vcache_tensor = vcache_tensor;
      attn_state->out_tensor = out_tensor;
      attn_state->softmax_scale = softmax_scale;
      attn_state->seq_lens = seq_lens;
      attn_state->seq_lens_tensor = seq_lens_tensor;
      attn_state->rank_block_tables_tensor = rank_block_tables_tensor;
      attn_state->micro_seq_lens_tensor_list = micro_seq_lens_tensor_list;
      attn_state->micro_block_tables_tensor_list = micro_block_tables_tensor_list;
      attn_state->micro_es_sum_tensor_list = micro_es_sum_tensor_list;
      attn_state->micro_es_min_tensor_list = micro_es_min_tensor_list;
      attn_state->micro_es_buffer_tensor = micro_es_buffer_tensor;
      attn_state->micro_output_tensor_list = micro_output_tensor_list;
      attn_state->micro_chunk_size = micro_chunk_size;
      attn_state->threshold = threshold;
      attn_state->max_num_chunks = micro_seq_lens_tensor_list.size(0);
      int batch_size = attn_state->seq_lens.size();
      cudaStreamSynchronize(stream);
      int max_iteration = attn_state->max_num_chunks;
      for (int i=0; i<max_iteration; i++) {
        load_chunk_block_table(attn_state, i);
        plain_attn_fwd_chunk(attn_state, i);
      }
      merge_attn_fwd(attn_state, max_iteration);
      std::vector<int64_t> results = {load_cnt_total, max_iteration};
      return results;
    }

    std::vector<int64_t> progressive_attn_parallel(int layer_idx,
                                          torch::Tensor& query_tensor,
                                          torch::Tensor& kcache_tensor,
                                          torch::Tensor& vcache_tensor,
                                          torch::Tensor& out_tensor,
                                          float softmax_scale,
                                          std::vector<int64_t> const& seq_lens,
                                          torch::Tensor& seq_lens_tensor,
                                          torch::Tensor& rank_block_tables_tensor,
                                          torch::Tensor& micro_seq_lens_tensor_list,
                                          torch::Tensor& micro_block_tables_tensor_list,
                                          torch::Tensor& micro_es_sum_tensor_list,
                                          torch::Tensor& micro_es_min_tensor_list,
                                          torch::Tensor& micro_es_buffer_tensor,
                                          torch::Tensor& micro_output_tensor_list,
                                          int micro_chunk_size,
                                          float threshold) {
      const cudaStream_t stream = at::cuda::getCurrentCUDAStream();
      int table_size_in_bytes = rank_block_tables_tensor.element_size() * rank_block_tables_tensor.numel();
      cudaMemcpyAsync(
        reinterpret_cast<int*>(rank_block_tables_tensor_cpu.data_ptr()),
        rank_block_tables_tensor.data_ptr(), 
        table_size_in_bytes, 
        cudaMemcpyDeviceToHost,
        stream
      );          
      AttnStatePtr attn_state = std::make_shared<AttnState>();
      attn_state->layer_idx = layer_idx;
      attn_state->query_tensor = query_tensor;
      attn_state->kcache_tensor = kcache_tensor;
      attn_state->vcache_tensor = vcache_tensor;
      attn_state->out_tensor = out_tensor;
      attn_state->softmax_scale = softmax_scale;
      attn_state->seq_lens = seq_lens;
      attn_state->seq_lens_tensor = seq_lens_tensor;
      attn_state->rank_block_tables_tensor = rank_block_tables_tensor;
      attn_state->micro_seq_lens_tensor_list = micro_seq_lens_tensor_list;
      attn_state->micro_block_tables_tensor_list = micro_block_tables_tensor_list;
      attn_state->micro_es_sum_tensor_list = micro_es_sum_tensor_list;
      attn_state->micro_es_min_tensor_list = micro_es_min_tensor_list;
      attn_state->micro_es_buffer_tensor = micro_es_buffer_tensor;
      attn_state->micro_output_tensor_list = micro_output_tensor_list;
      attn_state->micro_chunk_size = micro_chunk_size;
      attn_state->threshold = threshold;
      attn_state->max_num_chunks = micro_seq_lens_tensor_list.size(0);
      int batch_size = attn_state->seq_lens.size();
      cudaStreamSynchronize(stream);
      int max_iteration = attn_state->max_num_chunks;
      int compute_iteration;
      if (layer_idx < num_skip_layers) {
        load_cnt_total = plain_attn_fwd(attn_state);
        compute_iteration = max_iteration;
      } else {
        sync_load();
        reset_state(attn_state);
        is_finish = false;
        load_cnt_total = 0;
        load_budget = 1;
        compute_budget = 0;
        load_task_que.enqueue(attn_state);
        progessive_attn_fwd(attn_state);
        while (!is_all_finish(attn_state));
        compute_iteration = (*compute_barrier) / batch_size;
        merge_attn_fwd(attn_state, compute_iteration);
        compute_version++;
      }
      std::vector<int64_t> results = {load_cnt_total, compute_iteration};
      return results;
    }

    std::vector<int64_t> progressive_attn(int layer_idx,
                                          torch::Tensor& query_tensor,
                                          torch::Tensor& kcache_tensor,
                                          torch::Tensor& vcache_tensor,
                                          torch::Tensor& out_tensor,
                                          float softmax_scale,
                                          std::vector<int64_t> const& seq_lens,
                                          torch::Tensor& seq_lens_tensor,
                                          torch::Tensor& rank_block_tables_tensor,
                                          torch::Tensor& micro_seq_lens_tensor_list,
                                          torch::Tensor& micro_block_tables_tensor_list,
                                          torch::Tensor& micro_es_sum_tensor_list,
                                          torch::Tensor& micro_es_min_tensor_list,
                                          torch::Tensor& micro_es_buffer_tensor,
                                          torch::Tensor& micro_output_tensor_list,
                                          int micro_chunk_size,
                                          float threshold) {
      if (parallel_attn) {
        return progressive_attn_parallel(
          layer_idx,
          query_tensor,
          kcache_tensor,
          vcache_tensor,
          out_tensor,
          softmax_scale,
          seq_lens,
          seq_lens_tensor,
          rank_block_tables_tensor,
          micro_seq_lens_tensor_list,
          micro_block_tables_tensor_list,
          micro_es_sum_tensor_list,
          micro_es_min_tensor_list,
          micro_es_buffer_tensor,
          micro_output_tensor_list,
          micro_chunk_size,
          threshold
        );
      } else {
        return progressive_attn_sequential(
          layer_idx,
          query_tensor,
          kcache_tensor,
          vcache_tensor,
          out_tensor,
          softmax_scale,
          seq_lens,
          seq_lens_tensor,
          rank_block_tables_tensor,
          micro_seq_lens_tensor_list,
          micro_block_tables_tensor_list,
          micro_es_sum_tensor_list,
          micro_es_min_tensor_list,
          micro_es_buffer_tensor,
          micro_output_tensor_list,
          micro_chunk_size,
          threshold
        );
      }
    }

};

using AttnManagerPtr = std::shared_ptr<AttnManager>;

}
