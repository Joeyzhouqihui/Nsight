#pragma once

#include <torch/all.h>

// #include <faiss/gpu/utils/Select.cuh>

#include "concurrentqueue.h"
#include <atomic>
#include <vector>
#include <thread>
#include <memory>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>

namespace vllm {

struct IOTask {
  char *src_k, *dst_k;
  char *src_v, *dst_v;
  std::vector<int64_t> src_blocks, dst_blocks;
  cudaStream_t swap_stream;
};

struct IOManager {
  int64_t block_size_in_bytes;
  cudaStream_t swap_out_stream;
  std::thread *swap_out_thread;
  std::atomic<int> num_swap_out_tasks;
  moodycamel::ConcurrentQueue<IOTask> swap_out_task_que;
  std::atomic<bool> is_stop;

  IOManager(int64_t block_bytes) 
  : block_size_in_bytes(block_bytes),
    num_swap_out_tasks(0), 
    is_stop(false) {
      cudaStreamCreateWithFlags(&swap_out_stream, cudaStreamNonBlocking);
      swap_out_thread = new std::thread(&IOManager::swap_out_blocks_kv, this);
  }

  ~IOManager() {
    is_stop = true;
    swap_out_thread->join();
    delete swap_out_thread;
  }

  void swap_out_blocks_kv() {
    cudaMemcpyKind memcpy_type = cudaMemcpyDeviceToHost;
    while (!is_stop) {
      IOTask task;
      if (swap_out_task_que.try_dequeue(task)) {
        int num_blocks = task.src_blocks.size();
        cudaStream_t cur_stream = task.swap_stream;
        if (cur_stream == nullptr) {
          cur_stream = swap_out_stream;
        }
        for (int i=0; i<num_blocks; i++) {
          int64_t src_offset = task.src_blocks[i] * block_size_in_bytes;
          int64_t dst_offset = task.dst_blocks[i] * block_size_in_bytes;
          cudaMemcpyAsync(task.dst_k + dst_offset, task.src_k + src_offset,
            block_size_in_bytes, memcpy_type, cur_stream);
          cudaMemcpyAsync(task.dst_v + dst_offset, task.src_v + src_offset,
            block_size_in_bytes, memcpy_type, cur_stream);
        }
        cudaStreamSynchronize(cur_stream);
        num_swap_out_tasks--;
      }
    }
  }

  void swap_out(char *src_k, char *dst_k,
                char *src_v, char *dst_v,
                std::vector<int64_t> const& src_blocks, std::vector<int64_t> const& dst_blocks,
                cudaStream_t cur_stream) {
    IOTask task;
    task.src_k = src_k;
    task.dst_k = dst_k;
    task.src_v = src_v;
    task.dst_v = dst_v;
    task.src_blocks = src_blocks;
    task.dst_blocks = dst_blocks;
    task.swap_stream = cur_stream;
    num_swap_out_tasks++;
    swap_out_task_que.enqueue(task);
  }

  void sync_swap_out() {
    while (num_swap_out_tasks > 0);
  }

  void swap_in(char *src_k, char *dst_k,
               char *src_v, char *dst_v,
               std::vector<int64_t> const& src_blocks, std::vector<int64_t> const& dst_blocks,
               cudaStream_t cur_stream) {
    if (cur_stream == nullptr) {
      cur_stream = at::cuda::getCurrentCUDAStream();
    }
    int num_blocks = src_blocks.size();
    for (int i=0; i<num_blocks; i++) {
      int64_t src_offset = src_blocks[i] * block_size_in_bytes;
      int64_t dst_offset = dst_blocks[i] * block_size_in_bytes;
      cudaMemcpyAsync(dst_k + dst_offset, src_k + src_offset,
        block_size_in_bytes, cudaMemcpyHostToDevice, cur_stream);
      cudaMemcpyAsync(dst_v + dst_offset, src_v + src_offset,
        block_size_in_bytes, cudaMemcpyHostToDevice, cur_stream);
    }
  }

};

using IOManagerPtr = std::shared_ptr<IOManager>;

}

