#pragma once

#include <iostream>
#include <unordered_map>
#include <iterator>

namespace vllm {

template<typename K, typename V>
struct LRU {
  struct Entry {
    K key;
    V value;
    Entry *prev;
    Entry *next;
  };

  std::unordered_map<K, Entry*> dict;
  Entry *head, *tail;

  LRU() {
    head = new Entry();
    tail = new Entry();
    head->prev = nullptr;
    head->next = tail;
    tail->prev = head;
    tail->next = nullptr;
  }

  ~LRU() {
    while(head->next != tail) {
      delete detach(head->next);
    }
    delete head;
    delete tail;
  }

  inline Entry* detach(Entry *entry) {
    entry->prev->next = entry->next;
    entry->next->prev = entry->prev;
    return entry;
  }

  inline void push_front(Entry *entry) {
    entry->next = head->next;
    entry->next->prev = entry;
    entry->prev = head;
    head->next = entry;
  }

  inline void push_back(Entry *entry) {
    entry->next = tail;
    entry->prev = tail->prev;
    tail->prev->next = entry;
    tail->prev = entry;
  }

  inline void add(K key, V value) {
    Entry *entry = new Entry();
    entry->key = key;
    entry->value = value;
    push_front(entry);
    dict[key] = entry;
  }

  inline void add_back(K key, V value) {
    Entry *entry = new Entry();
    entry->key = key;
    entry->value = value;
    push_back(entry);
    dict[key] = entry;
  }
  
  inline void access(K key) {
    if (dict.find(key) != dict.end()) {
      Entry *entry = dict[key];
      detach(entry);
      push_front(entry);
    }
  }

  inline std::pair<K, V> evict() {
    Entry* entry = detach(tail->prev);
    std::pair<K, V> victim(entry->key, entry->value);
    dict.erase(entry->key);
    delete entry;
    return victim;
  }

  inline size_t size() {
    return dict.size();
  }

  inline void remove(K key) {
    if (dict.find(key) != dict.end()) {
      Entry* entry = dict[key];
      detach(entry);
      dict.erase(key);
      delete entry;
    }
  }

};

template<typename K, typename V>
struct FIFO {
  struct Entry {
    K key;
    V value;
    Entry *prev;
    Entry *next;
  };

  std::unordered_map<K, Entry*> dict;
  Entry *head, *tail;

  FIFO() {
    head = new Entry();
    tail = new Entry();
    head->prev = nullptr;
    head->next = tail;
    tail->prev = head;
    tail->next = nullptr;
  }

  ~FIFO() {
    while(head->next != tail) {
      delete detach(head->next);
    }
    delete head;
    delete tail;
  }

  inline Entry* detach(Entry *entry) {
    entry->prev->next = entry->next;
    entry->next->prev = entry->prev;
    return entry;
  }

  inline void push_front(Entry *entry) {
    entry->next = head->next;
    entry->next->prev = entry;
    entry->prev = head;
    head->next = entry;
  }

  void add(K key, V value) {
    Entry *entry = new Entry();
    entry->key = key;
    entry->value = value;
    push_front(entry);
    dict[key] = entry;
  }

  void access(K key) {
    if (dict.count(key) > 0) {
      Entry *entry = dict[key];
      detach(entry);
      push_front(entry);
    }
  }

  std::pair<K, V> evict() {
    Entry* entry = detach(tail->prev);
    std::pair<K, V> victim(entry->key, entry->value);
    dict.erase(entry->key);
    delete entry;
    return victim;
  }

  size_t size() {
    return dict.size();
  }

  void remove(K key) {
    if (dict.count(key) > 0) {
      Entry* entry = dict[key];
      detach(entry);
      dict.erase(key);
      delete entry;
    }
  }

};

}
