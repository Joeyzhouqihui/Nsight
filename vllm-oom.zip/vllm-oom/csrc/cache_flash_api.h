#pragma once

#include <torch/all.h>
#include <vector>
#include <semaphore.h>

extern void mha_fwd_kvcache(
  at::Tensor &q,                 // batch_size x seqlen_q x num_heads x head_size
  at::Tensor &kcache,            // batch_size_c x seqlen_k x num_heads_k x head_size or num_blocks x page_block_size x num_heads_k x head_size if there's a block_table.
  at::Tensor &vcache,            // batch_size_c x seqlen_k x num_heads_k x head_size or num_blocks x page_block_size x num_heads_k x head_size if there's a block_table.
  c10::optional<at::Tensor> &k_, // batch_size x seqlen_knew x num_heads_k x head_size
  c10::optional<at::Tensor> &v_, // batch_size x seqlen_knew x num_heads_k x head_size
  c10::optional<at::Tensor> &seqlens_k_, // batch_size
  c10::optional<at::Tensor> &rotary_cos_, // seqlen_ro x (rotary_dim / 2)
  c10::optional<at::Tensor> &rotary_sin_, // seqlen_ro x (rotary_dim / 2)
  c10::optional<at::Tensor> &cache_batch_idx_, // indices to index into the KV cache
  c10::optional<at::Tensor> &block_table_, // batch_size x max_num_blocks_per_seq
  c10::optional<at::Tensor> &alibi_slopes_, // num_heads or batch_size x num_heads
  c10::optional<at::Tensor> &out_,             // batch_size x seqlen_q x num_heads x head_size
  c10::optional<at::Tensor> &out_es_sum_,             // batch_size x seqlen_q x num_heads x head_size
  c10::optional<at::Tensor> &out_es_min_,             // batch_size x seqlen_q x num_heads x head_size
  c10::optional<at::Tensor> &out_es_buffer_,          // batch_size x seqlen_q x num_heads x head_size
  float softmax_scale,
  bool is_causal,
  int window_size_left,
  int window_size_right,
  bool is_rotary_interleaved,   // if true, rotary combines indices 0 & 1, else indices 0 & rotary_dim / 2
  int num_splits,
  int num_local_tokens,
  bool return_attn_weights);

extern void mha_fwd_kvcache_multiple(
  at::Tensor &q,                 // batch_size x seqlen_q x num_heads x head_size
  at::Tensor &kcache,            // batch_size_c x seqlen_k x num_heads_k x head_size or num_blocks x page_block_size x num_heads_k x head_size if there's a block_table.
  at::Tensor &vcache,            // batch_size_c x seqlen_k x num_heads_k x head_size or num_blocks x page_block_size x num_heads_k x head_size if there's a block_table.
  c10::optional<at::Tensor> &k_, // batch_size x seqlen_knew x num_heads_k x head_size
  c10::optional<at::Tensor> &v_, // batch_size x seqlen_knew x num_heads_k x head_size
  at::Tensor &seqlens_k_list_, // batch_size
  c10::optional<at::Tensor> &rotary_cos_, // seqlen_ro x (rotary_dim / 2)
  c10::optional<at::Tensor> &rotary_sin_, // seqlen_ro x (rotary_dim / 2)
  c10::optional<at::Tensor> &cache_batch_idx_, // indices to index into the KV cache
  at::Tensor &block_table_list_, // batch_size x max_num_blocks_per_seq
  c10::optional<at::Tensor> &alibi_slopes_, // num_heads or batch_size x num_heads
  at::Tensor &out_list_,             // batch_size x seqlen_q x num_heads x head_size
  at::Tensor &out_es_sum_list_,             // batch_size x seqlen_q x num_heads x head_size
  at::Tensor &out_es_min_list_,             // batch_size x seqlen_q x num_heads x head_size
  at::Tensor &out_es_buffer_,          // batch_size x seqlen_q x num_heads x head_size
  float softmax_scale,
  bool is_causal,
  int window_size_left,
  int window_size_right,
  bool is_rotary_interleaved,   // if true, rotary combines indices 0 & 1, else indices 0 & rotary_dim / 2
  int num_splits,
  int num_local_tokens,
  bool return_attn_weights,
  float *es_acc,
  float *es_min,
  int *total_seq_lens,
  int block_chunk_size,
  float threshold,
  std::atomic<int> &load_budget,
  std::atomic<int> &compute_budget,
  volatile int *seq_states,
  volatile int *compute_barrier);

void flash_attn_fwd(
    torch::Tensor &query_tensor,
    torch::Tensor &kcache_tensor,
    torch::Tensor &vcache_tensor,
    torch::Tensor &block_table_tensor_list,
    torch::Tensor &seqlens_tensor_list,
    torch::Tensor &out_tensor_list,
    torch::Tensor &out_es_sum_tensor_list,
    torch::Tensor &out_es_min_tensor_list,
    torch::Tensor &out_es_buffer_tensor,
    float softmax_scale,
    float *es_acc,
    float *es_min,
    int *total_seq_lens,
    int block_chunk_size,
    float threshold,
    std::atomic<int> &load_budget,
    std::atomic<int> &compute_budget,
    volatile int *seq_states,
    volatile int *compute_barrier
) {
    c10::optional<torch::Tensor> k_ = at::nullopt;
    c10::optional<torch::Tensor> v_ = at::nullopt;
    c10::optional<torch::Tensor> rotary_cos_ = at::nullopt;
    c10::optional<torch::Tensor> rotary_sin_ = at::nullopt;
    c10::optional<torch::Tensor> cache_batch_idx_ = at::nullopt;
    c10::optional<torch::Tensor> alibi_slopes_ = at::nullopt;
    mha_fwd_kvcache_multiple(
        query_tensor,
        kcache_tensor,
        vcache_tensor,
        k_,
        v_,
        seqlens_tensor_list,
        rotary_cos_,
        rotary_sin_,
        cache_batch_idx_,
        block_table_tensor_list,
        alibi_slopes_,
        out_tensor_list,
        out_es_sum_tensor_list,
        out_es_min_tensor_list,
        out_es_buffer_tensor,
        softmax_scale,
        true,
        -1,
        -1,
        true,
        0,
        0,
        true,
        es_acc,
        es_min,
        total_seq_lens,
        block_chunk_size,
        threshold,
        load_budget,
        compute_budget,
        seq_states,
        compute_barrier
    );
}

void flash_attn_fwd_plain_chunk(
    torch::Tensor &query_tensor,
    torch::Tensor &kcache_tensor,
    torch::Tensor &vcache_tensor,
    torch::Tensor &block_table_tensor,
    torch::Tensor &seqlens_tensor,
    torch::Tensor &out_tensor,
    torch::Tensor &out_es_sum_tensor,
    float softmax_scale
) {
    c10::optional<torch::Tensor> k_ = at::nullopt;
    c10::optional<torch::Tensor> v_ = at::nullopt;
    c10::optional<torch::Tensor> seqlens_k_ = seqlens_tensor;
    c10::optional<torch::Tensor> block_table_ = block_table_tensor;
    c10::optional<torch::Tensor> rotary_cos_ = at::nullopt;
    c10::optional<torch::Tensor> rotary_sin_ = at::nullopt;
    c10::optional<torch::Tensor> cache_batch_idx_ = at::nullopt;
    c10::optional<torch::Tensor> alibi_slopes_ = at::nullopt;
    c10::optional<torch::Tensor> out_ = out_tensor;
    c10::optional<torch::Tensor> out_es_sum_ = out_es_sum_tensor;
    c10::optional<torch::Tensor> out_es_min_ = at::nullopt;
    c10::optional<torch::Tensor> out_es_buffer_ = at::nullopt;
    c10::optional<torch::Tensor> num_remain_seqs = at::nullopt;
    mha_fwd_kvcache(
        query_tensor,
        kcache_tensor,
        vcache_tensor,
        k_,
        v_,
        seqlens_k_,
        rotary_cos_,
        rotary_sin_,
        cache_batch_idx_,
        block_table_,
        alibi_slopes_,
        out_,
        out_es_sum_,
        out_es_min_,
        out_es_buffer_,
        softmax_scale,
        true,
        -1,
        -1,
        true,
        0,
        0,
        false
    );
}

void flash_attn_fwd_plain(
    torch::Tensor &query_tensor,
    torch::Tensor &kcache_tensor,
    torch::Tensor &vcache_tensor,
    torch::Tensor &block_table_tensor,
    torch::Tensor &seqlens_tensor,
    torch::Tensor &out_tensor,
    float softmax_scale
) {
    c10::optional<torch::Tensor> k_ = at::nullopt;
    c10::optional<torch::Tensor> v_ = at::nullopt;
    c10::optional<torch::Tensor> seqlens_k_ = seqlens_tensor;
    c10::optional<torch::Tensor> block_table_ = block_table_tensor;
    c10::optional<torch::Tensor> rotary_cos_ = at::nullopt;
    c10::optional<torch::Tensor> rotary_sin_ = at::nullopt;
    c10::optional<torch::Tensor> cache_batch_idx_ = at::nullopt;
    c10::optional<torch::Tensor> alibi_slopes_ = at::nullopt;
    c10::optional<torch::Tensor> out_ = out_tensor;
    c10::optional<torch::Tensor> out_es_sum_ = at::nullopt;
    c10::optional<torch::Tensor> out_es_min_ = at::nullopt;
    c10::optional<torch::Tensor> out_es_buffer_ = at::nullopt;
    c10::optional<torch::Tensor> num_remain_seqs = at::nullopt;
    mha_fwd_kvcache(
        query_tensor,
        kcache_tensor,
        vcache_tensor,
        k_,
        v_,
        seqlens_k_,
        rotary_cos_,
        rotary_sin_,
        cache_batch_idx_,
        block_table_,
        alibi_slopes_,
        out_,
        out_es_sum_,
        out_es_min_,
        out_es_buffer_,
        softmax_scale,
        true,
        -1,
        -1,
        true,
        0,
        0,
        false
    );
}

namespace vllm {

__global__ 
void sync_load_kernel(volatile int *buffer_states, int iteration) {
  *(buffer_states + iteration) = 1;
}

void sync_load_flash(volatile int *buffer_states, int iteration, cudaStream_t stream) {
  sync_load_kernel<<<1, 1, 0, stream>>>(buffer_states, iteration);
}

// template <typename scalar_t>
// __global__ void merge_attn_flash_kernel(
//   const scalar_t* input_list,            // num_chunks, batch_size, num_heads, head_size
//   const float* es_list,                  // num_chunks, batch_size, num_heads
//   const int* seq_lens_list,              // num_chunks, batch_size
//   scalar_t* output,                      // batch_size, num_heads, head_size
//   const int batch_size, const int num_heads, const int head_size, 
//   const int max_iteration, const int iteration) {
//     const int seq_idx = blockIdx.x;
//     const int head_idx = blockIdx.y;
//     const int thread_idx = threadIdx.x;
//     const int num_threads = blockDim.x;
//     // merge attn outputs
//     extern __shared__ char shared_mem[];
//     float *sm_output = reinterpret_cast<float*>(shared_mem);
//     float acc_es = 0;
//     int num_iteration = std::min(max_iteration, iteration);
//     for (int i=0; i<num_iteration; i++) {
//       const int seq_len_offset = i * batch_size + seq_idx;
//       if (seq_lens_list[seq_len_offset] <= 0) {
//         break;
//       }
//       const int input_es_offset = i * batch_size * num_heads + seq_idx * num_heads + head_idx;
//       const float es = expf(es_list[input_es_offset]);
//       acc_es += es;
//     }
//     for (int i=0; i<num_iteration; i++) {
//       const int seq_len_offset = i * batch_size + seq_idx;
//       if (seq_lens_list[seq_len_offset] <= 0) {
//         break;
//       }
//       const int input_es_offset = i * batch_size * num_heads + seq_idx * num_heads + head_idx;
//       const int input_offset = input_es_offset * head_size;
//       const float weight = expf(es_list[input_es_offset]) / acc_es;
//       for (int j=thread_idx; j<head_size; j+=num_threads) {
//         if (i == 0) {
//           sm_output[j] = weight * float(input_list[input_offset + j]);
//         } else {
//           sm_output[j] += weight * float(input_list[input_offset + j]);
//         }
//       }
//     }
//     // save results
//     const int output_offset = (seq_idx * num_heads + head_idx) * head_size;
//     for (int i=thread_idx; i<head_size; i+=num_threads) {
//       output[output_offset + i] = scalar_t(sm_output[i]);
//     }
// }

template <typename scalar_t>
__global__ void merge_attn_flash_kernel(
  const scalar_t* input_list,            // num_chunks, batch_size, num_heads, head_size
  const float* es_list,                  // num_chunks, batch_size, num_heads
  const int* seq_lens_list,              // num_chunks, batch_size
  scalar_t* output,                      // batch_size, num_heads, head_size
  const int batch_size, const int num_heads, const int head_size, 
  const int max_iteration, const int iteration) {
    const int seq_idx = blockIdx.x;
    const int head_idx = blockIdx.y;
    const int thread_idx = threadIdx.x;
    const int num_threads = blockDim.x;
    // merge attn outputs
    extern __shared__ char shared_mem[];
    float *sm_output = reinterpret_cast<float*>(shared_mem);
    float acc_es = 0;
    int num_iteration = std::min(max_iteration, iteration);
    for (int i=0; i<num_iteration; i++) {
      const int seq_len_offset = i * batch_size + seq_idx;
      if (seq_lens_list[seq_len_offset] <= 0) {
        break;
      }
      const int input_es_offset = i * batch_size * num_heads + seq_idx * num_heads + head_idx;
      const int input_offset = input_es_offset * head_size;
      const float es = expf(es_list[input_es_offset]);
      acc_es += es;
      for (int j=thread_idx; j<head_size; j+=num_threads) {
        if (i == 0) {
          sm_output[j] = es * float(input_list[input_offset + j]);
        } else {
          sm_output[j] += es * float(input_list[input_offset + j]);
        }
      }
    }
    // save results
    const int output_offset = (seq_idx * num_heads + head_idx) * head_size;
    for (int i=thread_idx; i<head_size; i+=num_threads) {
      output[output_offset + i] = scalar_t(sm_output[i] / acc_es);
    }
}

}

#define CALL_MERGE_ATTN_FLASH(ATTN_T)                                        \
    vllm::merge_attn_flash_kernel<ATTN_T>                                    \
        <<<grid, block, smem_size, stream>>>(                                \
        reinterpret_cast<ATTN_T*>(input_tensor_list.data_ptr()),             \
        es_tensor_list.data_ptr<float>(),                                    \
        seq_lens_tensor_list.data_ptr<int>(),                                \
        reinterpret_cast<ATTN_T*>(output_tensor.data_ptr()),                 \
        batch_size, num_heads, head_size, max_iteration, iteration);

void merge_attn_flash(
  torch::Tensor& input_tensor_list,
  torch::Tensor& es_tensor_list,
  torch::Tensor& seq_lens_tensor_list,
  torch::Tensor& output_tensor,
  int64_t iteration) {
    int max_iteration = input_tensor_list.size(0);
    int batch_size = input_tensor_list.size(1);
    int num_heads = input_tensor_list.size(2);
    int head_size = input_tensor_list.size(3);
    const at::cuda::OptionalCUDAGuard device_guard(device_of(input_tensor_list));
    const cudaStream_t stream = at::cuda::getCurrentCUDAStream();
    dim3 grid(batch_size, num_heads);
    dim3 block(head_size);
    int smem_size = head_size * 4;
    auto input_attn_dtype = input_tensor_list.dtype();
    auto output_attn_dtype = output_tensor.dtype();
    TORCH_CHECK(input_attn_dtype == output_attn_dtype, "attn type mismatch"); 
    if (input_attn_dtype == at::ScalarType::Half) {
      CALL_MERGE_ATTN_FLASH(__half);
    } else {
      CALL_MERGE_ATTN_FLASH(__nv_bfloat16);
    }
}
